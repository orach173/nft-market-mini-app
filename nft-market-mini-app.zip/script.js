function buyNFT(){ alert('Buy NFT function coming soon'); }
function sellNFT(){ alert('Sell NFT function coming soon'); }
function exchangeNFT(){ alert('Exchange NFT function coming soon'); }